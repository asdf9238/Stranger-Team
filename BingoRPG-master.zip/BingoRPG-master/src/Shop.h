#ifndef BINGORPG_SHOP_H
#define BINGORPG_SHOP_H

class Shop {
public:
    static void printStore();
    static void buyItem(int kind);
    static void buyCloak(int kind);
};

#endif //BINGORPG_SHOP_H
